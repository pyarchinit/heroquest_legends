<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en">
<context>
    <name>Heroquest_MainWindow_ui</name>
    <message>
        <location filename="heroquest_legends.ui" line="42"/>
        <source>Heroquest Legend&apos;s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="600"/>
        <source>What size is the room (write the number of tiles)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="631"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Viner Hand ITC&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="828"/>
        <source>Are there any secret doors or pitfalls?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="1032"/>
        <location filename="heroquest_legends.ui" line="4018"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="1234"/>
        <location filename="heroquest_legends.ui" line="4454"/>
        <source>Not explored</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="1431"/>
        <location filename="heroquest_legends.ui" line="4597"/>
        <source>Explored</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="1637"/>
        <source>Find out how the room is made</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="2099"/>
        <source>Discover the mission that Mentor has for you</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="2573"/>
        <source>How the dungeon is made</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="2756"/>
        <source>What&apos;s inside?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="2797"/>
        <location filename="heroquest_legends.ui" line="7422"/>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="2802"/>
        <source>2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="2807"/>
        <source>3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="2812"/>
        <source>4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="2986"/>
        <source>Draw a card from the treasure deck</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="3165"/>
        <source>There are treasures in the ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="3606"/>
        <source>What kind of room is...?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="3821"/>
        <source>Tiles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="4833"/>
        <source>Room</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="5036"/>
        <source>6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="5244"/>
        <source>Monster section</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="5782"/>
        <source>Figthing System</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="5919"/>
        <source>See you?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="6047"/>
        <source>Chronicle Section</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="6348"/>
        <source>In group?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="6782"/>
        <source>The hero attacks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="6979"/>
        <source>Round</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="7601"/>
        <source>Next Round</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="7738"/>
        <source>Hero section</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="7911"/>
        <source>The monster ....</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="8096"/>
        <source>Open Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="8233"/>
        <source>Quit...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
