<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="it_IT" sourcelanguage="en">
<context>
    <name>Heroquest_MainWindow_ui</name>
    <message>
        <location filename="heroquest_legends.ui" line="32"/>
        <source>Heroquest Legend&apos;s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="76"/>
        <source>Round</source>
        <translation type="unfinished">Turno</translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="95"/>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="114"/>
        <source>Next Round</source>
        <translation type="unfinished">Prossimo turno</translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="155"/>
        <source>The monster ....</source>
        <translation type="unfinished">Il mostro ...</translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="168"/>
        <source>Quit</source>
        <translation type="unfinished">Esci</translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="191"/>
        <source>See you?</source>
        <translation type="unfinished">Ti vede?</translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="201"/>
        <source>In group?</source>
        <translation type="unfinished">E&apos; in gruppo?</translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="208"/>
        <source>The hero attacks</source>
        <translation type="unfinished">L&apos;eroe attacca!</translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="218"/>
        <source>Monsters section</source>
        <translation type="unfinished">Sezione mostri</translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="228"/>
        <source>Hero section</source>
        <translation type="unfinished">Sezione Eroe</translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="256"/>
        <source>Figthing System</source>
        <translation type="unfinished">Sistema di combattimento</translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="316"/>
        <source>What size is the room (write the number of tiles)</source>
        <translation type="unfinished">Quanto è grande la stanza (Scrivi il totale mattonelle)</translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="362"/>
        <source>Tiles</source>
        <translation type="unfinished">Mattonelle</translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="375"/>
        <source>Find out how the room is made</source>
        <translation type="unfinished">Scopri come è fatta la stanza</translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="388"/>
        <source>6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="407"/>
        <source>What&apos;s inside?</source>
        <translation type="unfinished">Cosa contiene</translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="432"/>
        <source>Are there any secret doors or pitfalls?</source>
        <translation type="unfinished">Ci sono porte segrete o trabocchetti</translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="474"/>
        <location filename="heroquest_legends.ui" line="703"/>
        <source>Not explored</source>
        <translation type="unfinished">Non esplorata</translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="508"/>
        <source>How the dungeon is made</source>
        <translation type="unfinished">Come è fatto il corridoio</translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="524"/>
        <source>Discover the mission that Mentor has for you</source>
        <translation type="unfinished">Scopri la missione che Mentor ha per te</translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="540"/>
        <location filename="heroquest_legends.ui" line="722"/>
        <source>Explored</source>
        <translation type="unfinished">Esplorato</translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="600"/>
        <source>There are treasures in the ...</source>
        <translation type="unfinished">Ci sono tesori nel ...</translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="617"/>
        <source>Room</source>
        <translation type="unfinished">Stanza</translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="640"/>
        <source>What kind of room is...?</source>
        <translation type="unfinished">Che tipo di stanza è ... ?</translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="666"/>
        <source>Draw a card from the treasure deck</source>
        <translation type="unfinished">Pesca una carta</translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="688"/>
        <source>Type</source>
        <translation type="unfinished">Tipo</translation>
    </message>
</context>
</TS>
