# Heroquest's Legends

This is a simple A.I. app for playing heroquest without the dungeon master.

It is a python app which use modules pySimpleGui and random.

Download the code ore the .exe files for testing and open issue for improvements or bugs!
