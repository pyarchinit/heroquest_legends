<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="es_ES">
<context>
    <name>Heroquest_MainWindow_ui</name>
    <message>
        <location filename="heroquest_legends.ui" line="32"/>
        <source>Heroquest Legend&apos;s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="76"/>
        <source>Round</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="95"/>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="114"/>
        <source>Next Round</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="155"/>
        <source>The monster ....</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="168"/>
        <source>Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="191"/>
        <source>See you?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="201"/>
        <source>In group?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="208"/>
        <source>The hero attacks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="218"/>
        <source>Monsters section</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="228"/>
        <source>Hero section</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="256"/>
        <source>Figthing System</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="316"/>
        <source>What size is the room (write the number of tiles)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="362"/>
        <source>Tiles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="375"/>
        <source>Find out how the room is made</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="388"/>
        <source>6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="407"/>
        <source>What&apos;s inside?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="432"/>
        <source>Are there any secret doors or pitfalls?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="474"/>
        <location filename="heroquest_legends.ui" line="703"/>
        <source>Not explored</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="508"/>
        <source>How the dungeon is made</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="524"/>
        <source>Discover the mission that Mentor has for you</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="540"/>
        <location filename="heroquest_legends.ui" line="722"/>
        <source>Explored</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="600"/>
        <source>There are treasures in the ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="617"/>
        <source>-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="640"/>
        <source>What kind of room is...?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="666"/>
        <source>Draw a card from the treasure deck</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="heroquest_legends.ui" line="688"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
